#
# Diet problem
#

import sys
from gurobipy import *

try:
	# Create a new model
	m = Model("Diet")

	#
	# TODO: create variables
	#	myVar = m.addVar(lb=a, ub=b, vtype=GRB.CONTINUOUS, name="myVar")
	# 	GUROBI variable types: GRB.CONTINUOUS, GRB.BINARY, GRB.INTEGER, GRB.SEMICONT, GRB.SEMIINT
	#
	

	#	
	# TODO: set objective
	#	m.setObjective( a*x+b*y, GRB.MINIMIZE )
	#


	#
	# TODO: add constraints
	#	m.addConstr( a*x + b*y <= c, "myConstraint")
	#


	# Run
	m.optimize()
	
	# Print solution
	for v in m.getVars():
		print(v.varName, v.x)
	print('Obj:', m.objVal)

except GurobiError:
	print('Error reported')
