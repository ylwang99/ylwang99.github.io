#
# Maximum matching in bipartite graphs
#

import sys, ast
from gurobipy import *

# small graph 
edgeList = [ (1,1), (1,2), (2,1), (2,3), (3,3), (3,4), (4,2), (4,3) ]

# larger graph
#fin = open("bipgraph.txt", 'r')        # this graph is bipartite; |U|=2386, |V|=405, numEdges=2787
#ln = fin.readline()
#while ln.startswith("#"):
#    ln = fin.readline()
#edgeList = ast.literal_eval(ln)



numEdges = len(edgeList)
U, V = zip( *edgeList )
U = set(U)
V = set(V)

nU = len(U)
nV = len(V)
n = nU + nV

#assert U == set(range(1,nU+1))
#assert V == set(range(1,nV+1))

try:
	# Create a new model
	m = Model("MCM_bipartite")



    #
    # TODO: create edge variables
    #   myVar = m.addVar(lb=a, ub=b, vtype=GRB.CONTINUOUS, name="myVar")
    #   GUROBI variable types: GRB.CONTINUOUS, GRB.BINARY, GRB.INTEGER, GRB.SEMICONT, GRB.SEMIINT
    #


    #       
    # TODO: set objective
    #   m.setObjective( a*x+b*y, GRB.MINIMIZE )
	# OR    
	#   myLinearExpression = LinExpr()
	#   myLinearExpression += (a*x)
	#   myLinearExpression += (b*y)
	#   m.setObjective( myLinearExpression , GRB.MINIMIZE )
	#



	#
	# TODO: add U constraints
   	#   m.addConstr( a*x + b*y <= c, "myConstraint")
    #



	#
	# TODO: add V constraints
   	#   m.addConstr( a*x + b*y <= c, "myConstraint")
    #


	# Run
	m.optimize()

	# Print solution
	for v in m.getVars():
		print v.varName, v.x
	print 'Obj:', m.objVal

except GurobiError:
	print('Error reported')
