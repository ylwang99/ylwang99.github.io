#
# k-median problem as an IP
#

import sys, ast, math
from gurobipy import *

def distance(x1, y1, x2, y2):
	return math.sqrt( (x1-x2)**2 + (y1-y2)**2 )

# Graph information
locationsFile = "cities_graph.txt"
fin = open(locationsFile, 'r')
ln = fin.readline()
coords = ast.literal_eval(ln)
cities = coords.keys()
print len(coords)

n = len(coords)
k = 10 

V = range(n)
try:
	# Create a new model
	m = Model("k_median")

    #
    # TODO: create variables
    #   myVar = m.addVar(lb=a, ub=b, vtype=GRB.CONTINUOUS, name="myVar")
    #   GUROBI variable types: GRB.CONTINUOUS, GRB.BINARY, GRB.INTEGER, GRB.SEMICONT, GRB.SEMIINT
    #
    

    #       
    # TODO: set objective.  Use distance() method above
    #   m.setObjective( a*x+b*y, GRB.MINIMIZE )
	# OR    
	#   myLinearExpression = LinExpr()
	#   myLinearExpression += (a*x)
	#   myLinearExpression += (b*y)
	#   m.setObjective( myLinearExpression , GRB.MINIMIZE )
    #


	#
	# TODO: add constraint to open at most k centers
   	#   m.addConstr( a*x + b*y <= c, "myConstraint")
    #

	#
	# TODO: add constraints that cities connect to open centers only
	#

	#
	# TODO: add constraints that each city connects to some center
	#


	# Run
	m.optimize()

	# Print solution
	for v in m.getVars():
		if v.x != 0.0:
			print v.varName, v.x
	print 'Obj:', m.objVal

except GurobiError:
	print('Error reported')
