#
# k-median IP
#

import sys, ast, math
from gurobipy import *

# small graph information
k = 2
n = 6

D = [ [0, 3, 4, 5, 6, 9],
	  [3, 0, 2, 3, 3, 7],
	  [4, 2, 3, 5, 3, 5],
	  [5, 3, 5, 0, 3, 6],
	  [6, 3, 3, 3, 0, 4],
	  [9, 7, 5, 6, 4, 0] ]

assert len(D) == n

V = range(n)
try:
	# Create a new model
	m = Model("k_median")


	#
	# TODO: create variables
	#	myVar = m.addVar(lb=a, ub=b, vtype=GRB.CONTINUOUS, name="myVar")
	# 	GUROBI variable types: GRB.CONTINUOUS, GRB.BINARY, GRB.INTEGER, GRB.SEMICTON, GRB.SEMIINT
	#
	

	#	
	# TODO: set objective
	#	m.setObjective( a*x+b*y, GRB.MINIMIZE )
	# OR    
	#   myLinearExpression = LinExpr()
	#   myLinearExpression += (a*x)
	#   myLinearExpression += (b*y)
	#   m.setObjective( myLinearExpression , GRB.MINIMIZE )
	#


	#
	# TODO: add constraints
	#	m.addConstr( a*x + b*y <= c, "myConstraint")
	#



	# Run
	m.optimize()

	# Print solution
	for v in m.getVars():
		if v.x != 0.0:
			print v.varName, v.x
	print 'Obj:', m.objVal

except GurobiError:
	print('Error reported')
